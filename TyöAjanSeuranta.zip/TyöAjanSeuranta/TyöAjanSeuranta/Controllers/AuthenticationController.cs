﻿using Microsoft.AspNetCore.Mvc;
using TyöAjanSeuranta.Services.Interfaces;
using TyöAjanSeuranta.Models;

namespace TyöAjanSeuranta.Controllers
{
    [Route("Työajanseuranta/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private IAuthenticateService _authenticateService;

        public AuthenticationController(IAuthenticateService authenticateService)
        {
            _authenticateService = authenticateService;
        }

        [HttpPost]
        public IActionResult Post([FromBody] User model)
        {
            var user = _authenticateService.Authenticate(model.KäyttäjäNimi, model.Salasana);

            if (user == null)
                return BadRequest(new { message = "Käyttäjätunus tai salasana on virheellinen" });

            return Ok(user); // Palautus front endiin
        }
    }
}
