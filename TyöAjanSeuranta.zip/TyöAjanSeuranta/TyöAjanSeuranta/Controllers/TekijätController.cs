﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TyöAjanSeuranta.Models;


namespace TyöAjanSeuranta.Controllers
{
    [Route("työajanseuranta/[controller]")]
    [ApiController]
    public class TekijätController : ControllerBase
    {
        private TyöajanseurantaContext db = new TyöajanseurantaContext();

        [HttpGet]
        [Route("")]
        public List<Tekijät> GetAllEmployees() //Hakee kaikki rivit
        {

            List<Tekijät> henkiklokunta = db.Tekijät.ToList();
            return henkiklokunta;
        }

        [HttpGet]
        [Route("{id}")]
        public Tekijät GetOneEmployee(int id) //Find-metodi hakee AINA VAIN PÄÄAVAIMELLA YHDEN RIVIN
        {

            Tekijät henkikokunta = db.Tekijät.Find(id);
            return henkikokunta;
        }

        [HttpGet]
        [Route("Tekijä/{key}")]
        public List<Tekijät> GetSomeEmployees(string key) 
        {

            var somehenkilokunta = from l in db.Tekijät //LinQ kysely
                                where l.Tekijä == key
                                select l;

            return somehenkilokunta.ToList();
        }

        [HttpPost]
        [Route("")]
        public ActionResult PostCreateNew([FromBody] Tekijät henkilokunta) //Lisää uuden "Työntekijän"
        {
            try
            {
                db.Tekijät.Add(henkilokunta);
                db.SaveChanges();
                return Ok(henkilokunta.TekijäId);
            }
            catch (Exception e)
            {
                return BadRequest("Työntekijän lisääminen ei onnistu. Alla lisätietoa" + e);
            }
            finally
            {
                db.Dispose();
            }
        }

        [HttpDelete]
        [Route("{key}")]
        public ActionResult DeleteEmployee(int key)//Poistaa "Työntekijän"
        {
            try
            {
                Tekijät henkilokunta = db.Tekijät.Find(key);
                if (henkilokunta != null)
                {
                    try
                    {
                        db.Tekijät.Remove(henkilokunta);
                        db.SaveChanges();
                        Console.WriteLine(key + " poistettiin");
                        return Ok("Tekijä " + key + " poistettiin");
                    }
                    catch (Exception e)
                    {
                        return BadRequest("Poistaminen ei onnistu. Onko työntekijällä työaika kuittaamatta? Palvelimen virheilmoitus:" + e);
                    }
                }
                else
                {
                    return NotFound("Työntekijää " + key + " ei löydy");
                }
            }
            finally
            {
                db.Dispose();
            }
        }

        [HttpPut]
        [Route("{key}")]
        public ActionResult PutEdit(int key, [FromBody] Tekijät henkilokunta) //Antaa editoida "Työntekijää" (muista ID)
        {
            try
            {
                Tekijät tekijä = db.Tekijät.Find(key);
                if (tekijä != null)
                {
                    tekijä.Tekijä = henkilokunta.Tekijä;

                    db.SaveChanges();
                    return Ok(tekijä.TekijäId);
                }
                {
                    return NotFound("Päivitettävää työntekijää ei löytynyt!");
                }
            }
            catch (Exception e)
            {
                return BadRequest("Jokin meni pieleen työntekijää päivitääessä. Alla lisätietoa:" + e);
            }
            finally
            {
                db.Dispose();
            }
        }

    }
}
