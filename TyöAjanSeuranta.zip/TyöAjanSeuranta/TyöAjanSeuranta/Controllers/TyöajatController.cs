﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TyöAjanSeuranta.Models;

namespace TyöAjanSeuranta.Controllers
{
    [Route("työajanseuranta/[controller]")]
    [ApiController]
    public class TyöajatController : Controller
    {
        private TyöajanseurantaContext db = new TyöajanseurantaContext();

        [HttpGet]
        [Route("")]
        public ActionResult GetAllTyöajat() //Hakee kaikki rivit
        {

            var työaika = from ta in db.Työajat join t in db.Tekijät on ta.TekijäId equals t.TekijäId join tm in db.Työmaat on ta.TyömaaId equals tm.TyömaaId select ta;
            return Ok(työaika.ToList()); //Tekee taulu liitoksen ID:llä 
        }


        [HttpGet]
        [Route("Työajat/{key}")]
        public List<Työajat> GetSomeTyöajat(int key) 
        {

            var sometyöaika = from l in db.Työajat //LinQ kysely
                                   where l.TekijäId == key
                                   select l;

            return sometyöaika.ToList();
        }

        [HttpPost]
        [Route("")]
        public ActionResult PostCreateNew([FromBody] Työajat työaika) //Lisää uuden "Työaikan"
        {
            try
            {
                db.Työajat.Add(työaika);
                db.SaveChanges();
                return Ok(työaika.TekijäId);
            }
            catch (Exception e)
            {
                return BadRequest("Työajan lisääminen ei onnistu. Alla lisätietoa" + e);
            }
            finally
            {
                db.Dispose();
            }
        }

        [HttpDelete]
        [Route("{key}")]
        public ActionResult DeleteTyöajat(int key)//Poistaa "Työntekijän"
        {
            try
            {
                Työajat työaika = db.Työajat.Find(key);
                if (työaika != null)
                {
                    try
                    {
                        db.Työajat.Remove(työaika);
                        db.SaveChanges();
                        Console.WriteLine(key + " poistettiin");
                        return Ok("Työaika " + key + " poistettiin");
                    }
                    catch (Exception e)
                    {
                        return BadRequest("Poistaminen ei onnistu. Onko työaika kuittaamatta? Palvelimen virheilmoitus:" + e);
                    }
                }
                else
                {
                    return NotFound("Työntekijää " + key + " ei löydy");
                }
            }
            finally
            {
                db.Dispose();
            }
        }

        [HttpPut]
        [Route("{key}")]
        public ActionResult PutEdit(int key, [FromBody] Työajat työaika) //Antaa editoida "Työaikaa" (muista ID)
        {
            try
            {
                Työajat työajat = db.Työajat.Find(key);
                if (työajat != null)
                {
                    työajat.TekijäId = työaika.TekijäId;
                    työajat.Alkamisaika = työaika.Alkamisaika;
                    työajat.Päättymisaika = työaika.Päättymisaika;
                    db.SaveChanges();
                    return Ok(työajat.TyöId);
                }
                {
                    return NotFound("Päivitettävää työaika ei löytynyt!");
                }
            }
            catch (Exception e)
            {
                return BadRequest("Jokin meni pieleen työaikaa päivitääessä. Alla lisätietoa:" + e);
            }
            finally
            {
                db.Dispose();
            }
        }

    }

}
