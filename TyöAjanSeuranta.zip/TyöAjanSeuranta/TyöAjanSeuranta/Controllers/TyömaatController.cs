﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TyöAjanSeuranta.Models;


namespace TyöAjanSeuranta.Controllers
{
    [Route("työajanseuranta/[controller]")]
    [ApiController]
    public class TyömaatController : ControllerBase
    {
        private TyöajanseurantaContext db = new TyöajanseurantaContext();

        [HttpGet]
        [Route("")]
        public List<Työmaat> GetAllEmployees() //Hakee kaikki rivit
        {

            List<Työmaat> henkiklokunta = db.Työmaat.ToList();
            return henkiklokunta;
        }

        [HttpGet]
        [Route("{id}")]
        public Työmaat GetOneEmployee(int id) //Find-metodi hakee AINA VAIN PÄÄAVAIMELLA YHDEN RIVIN
        {

            Työmaat henkikokunta = db.Työmaat.Find(id);
            return henkikokunta;
        }

        [HttpGet]
        [Route("Työmaat/{key}")]
        public List<Työmaat> GetSomeEmployees(int key) 
        {

            var somehenkilokunta = from l in db.Työmaat //LinQ kysely
                                   where l.TyömaaId == key
                                   select l;

            return somehenkilokunta.ToList();
        }

        [HttpPost]
        [Route("")]
        public ActionResult PostCreateNew([FromBody] Työmaat henkilokunta) //Lisää uuden "Työntekijän"
        {
            try
            {
                db.Työmaat.Add(henkilokunta);
                db.SaveChanges();
                return Ok(henkilokunta.TyömaaId);
            }
            catch (Exception e)
            {
                return BadRequest("Työntekijän lisääminen ei onnistu. Alla lisätietoa" + e);
            }
            finally
            {
                db.Dispose();
            }
        }

        [HttpDelete]
        [Route("{key}")]
        public ActionResult DeleteEmployee(int key)//Poistaa "Työntekijän"
        {
            try
            {
                Työmaat henkilokunta = db.Työmaat.Find(key);
                if (henkilokunta != null)
                {
                    try
                    {
                        db.Työmaat.Remove(henkilokunta);
                        db.SaveChanges();
                        Console.WriteLine(key + " poistettiin");
                        return Ok("Tekijä " + key + " poistettiin");
                    }
                    catch (Exception e)
                    {
                        return BadRequest("Poistaminen ei onnistu. Onko työntekijällä työaika kuittaamatta? Palvelimen virheilmoitus:" + e);
                    }
                }
                else
                {
                    return NotFound("Työntekijää " + key + " ei löydy");
                }
            }
            finally
            {
                db.Dispose();
            }
        }

        [HttpPut]
        [Route("{key}")]
        public ActionResult PutEdit(int key, [FromBody] Työmaat työmaa) //Antaa editoida "Työntekijää" (muista ID)
        {
            try
            {
                Työmaat työkohde = db.Työmaat.Find(key);
                if (työkohde != null)
                {
                    työkohde.Työkohde = työmaa.Työkohde;
                    työkohde.Työtehtävä = työmaa.Työtehtävä;

                    db.SaveChanges();
                    return Ok(työkohde.TyömaaId);
                }
                {
                    return NotFound("Päivitettävää työntekijää ei löytynyt!");
                }
            }
            catch (Exception e)
            {
                return BadRequest("Jokin meni pieleen työntekijää päivitääessä. Alla lisätietoa:" + e);
            }
            finally
            {
                db.Dispose();
            }
        }

    }
}
