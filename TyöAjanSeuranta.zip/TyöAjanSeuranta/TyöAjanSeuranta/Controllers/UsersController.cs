﻿using System;
using System.Collections.Generic;
using System.Linq;
using TyöAjanSeuranta.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;

namespace TyöAjanSeuranta.Controllers
{
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]

    [Route("työajanseuranta/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private TyöajanseurantaContext db = new TyöajanseurantaContext();

        [HttpGet]
        [Route("")]
        public List<User> GetAllUsers() //Hakee kaikki rivit
        {

            List<User> kirjautuneet = db.Users.ToList();
            return kirjautuneet;
        }

        [HttpGet]
        [Route("{id}")]
        public User GetOneUsers(int id) //Find-metodi hakee AINA VAIN PÄÄAVAIMELLA YHDEN RIVIN
        {

            User kirjautunut = db.Users.Find(id);
            return kirjautunut;
        }

        [HttpGet]
        [Route("country/{key}")]
        public List<User> GetSomeUsers(string key) //Hakee jollain tiedolla sopivat rivit "työajanseuranta/tekijät/tekijä/Heikki" korvaa Heikki jollain tekijän nimellä mitä ei ole listassa saat "0"
        {


            var someUser = from f in db.Users //LinQ kysely
                            where f.KäyttäjäNimi == key
                            select f;

            return someUser.ToList();
        }

        [HttpPost]
        [Route("")]
        public ActionResult PostCreateNew([FromBody] User kirjautunut) //Lisää uuden "Kirjautujan"
        {
            try
            {
                db.Users.Add(kirjautunut);
                db.SaveChanges();
                return Ok(kirjautunut.UserId);
            }
            catch (Exception e)
            {
                return BadRequest("Kirjautujan lisääminen ei onnistu. Alla lisätietoa" + e);
            }
            finally
            {
                db.Dispose();
            }
        }

        [HttpDelete]
        [Route("{key}")]
        public ActionResult DeleteLogin(int key)//Poistaa "Asiakkaan"
        {
            try
            {
                User kirjautunut = db.Users.Find(key);
                if (kirjautunut != null)
                {
                    try
                    {
                        db.Users.Remove(kirjautunut);
                        db.SaveChanges();
                        Console.WriteLine(key + " poistettiin");
                        return Ok("Kirjautuja " + key + " poistettiin");
                    }
                    catch (Exception e)
                    {
                        return BadRequest("Poistaminen ei onnistu. Onko kirjautujalla tilauksia? Palvelimen virheilmoitus:" + e);
                    }
                }
                else
                {
                    return NotFound("Kirjautuja " + key + " ei löydy");
                }
            }
            finally
            {
                db.Dispose();
            }
        }

        [HttpPut]
        [Route("{key}")]
        public ActionResult PutEdit(int key, [FromBody] User kirjautuja) //Antaa editoida "Asiakasta" (muista ID "ALFKI")
        {
            try
            {
                User user = db.Users.Find(key);
                if (user != null)
                {
                    user.KäyttäjäNimi = kirjautuja.KäyttäjäNimi;
                    user.Salasana = kirjautuja.Salasana;
                    user.TurvaLuokitus = kirjautuja.TurvaLuokitus;

                    db.SaveChanges();
                    return Ok(user.UserId);
                }
                {
                    return NotFound("Päivitettävää kirjautujaa ei löytynyt!");
                }
            }
            catch (Exception e)
            {
                return BadRequest("Jokin meni pieleen kirjautujaa päivitääessä. Alla lisätietoa:" + e);
            }
            finally
            {
                db.Dispose();
            }
        }
    }
}
