﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TyöAjanSeuranta.Models
{
    public partial class Tekijät
    {
        public int TekijäId { get; set; }
        public string Tekijä { get; set; }
    }
}
