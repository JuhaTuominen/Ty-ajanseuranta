﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace TyöAjanSeuranta.Models
{
    public partial class TyöajanseurantaContext : DbContext
    {
        public TyöajanseurantaContext()
        {
        }

        public TyöajanseurantaContext(DbContextOptions<TyöajanseurantaContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Tekijät> Tekijät { get; set; }
        public virtual DbSet<Työajat> Työajat { get; set; }
        public virtual DbSet<Työmaat> Työmaat { get; set; }
        public virtual DbSet<User> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=tcp:sqlpalvelin12.database.windows.net,1433;Initial Catalog=Työajanseuranta;Persist Security Info=False;User ID=Juha;Password=xvRbCkn7vCrhF84;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "Finnish_Swedish_CI_AS");

            modelBuilder.Entity<Tekijät>(entity =>
            {
                entity.HasKey(e => e.TekijäId);

                entity.ToTable("Tekijät");

                entity.Property(e => e.TekijäId).HasColumnName("Tekijä_ID");

                entity.Property(e => e.Tekijä)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Työajat>(entity =>
            {
                entity.HasKey(e => e.TyöId);

                entity.ToTable("Työajat");

                entity.Property(e => e.TyöId).HasColumnName("Työ_ID");

                entity.Property(e => e.Alkamisaika).HasColumnType("date");

                entity.Property(e => e.Päättymisaika).HasColumnType("date");

                entity.Property(e => e.TekijäId).HasColumnName("Tekijä_ID");

                entity.Property(e => e.TyömaaId).HasColumnName("Työmaa_ID");

                entity.HasOne(d => d.Työmaa)
                    .WithMany(p => p.Työajats)
                    .HasForeignKey(d => d.TyömaaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Työmaat_Työajat");
            });

            modelBuilder.Entity<Työmaat>(entity =>
            {
                entity.HasKey(e => e.TyömaaId);

                entity.ToTable("Työmaat");

                entity.Property(e => e.TyömaaId).HasColumnName("Työmaa_ID");

                entity.Property(e => e.Työkohde)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Työtehtävä)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.Property(e => e.UserId).HasColumnName("UserID");

                entity.Property(e => e.KäyttäjäNimi).HasMaxLength(50);

                entity.Property(e => e.Salasana).HasMaxLength(50);

                entity.Property(e => e.Token).HasMaxLength(2000);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
