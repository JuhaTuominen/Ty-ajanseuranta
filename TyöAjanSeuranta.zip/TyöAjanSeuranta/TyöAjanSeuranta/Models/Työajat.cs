﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TyöAjanSeuranta.Models
{
    public partial class Työajat
    {
        public int TekijäId { get; set; }
        public DateTime Alkamisaika { get; set; }
        public DateTime Päättymisaika { get; set; }
        public int TyöId { get; set; }
        public int TyömaaId { get; set; }

        public virtual Työmaat Työmaa { get; set; }
    }
}
