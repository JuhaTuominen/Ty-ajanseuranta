﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TyöAjanSeuranta.Models
{
    public partial class Työmaat
    {
        public Työmaat()
        {
            Työajats = new HashSet<Työajat>();
        }

        public int TyömaaId { get; set; }
        public string Työkohde { get; set; }
        public string Työtehtävä { get; set; }

        public virtual ICollection<Työajat> Työajats { get; set; }
    }
}
