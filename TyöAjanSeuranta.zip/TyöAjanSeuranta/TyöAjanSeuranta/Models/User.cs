﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TyöAjanSeuranta.Models
{
    public partial class User
    {
        public int UserId { get; set; }
        public string KäyttäjäNimi { get; set; }
        public string Salasana { get; set; }
        public int? TurvaLuokitus { get; set; }
        public string Token { get; set; }
    }
}
