﻿using TyöAjanSeuranta.Models;
using Microsoft.Extensions.Options;
using System.IdentityModel.Tokens.Jwt;
using System;
using System.Text;
using System.Linq;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;

using TyöAjanSeuranta.Services.Interfaces;

namespace TyöAjanSeuranta.Services
{
    public class AuthenticateService : IAuthenticateService
    {
        private readonly AppSettings _appSettings;
        public AuthenticateService(IOptions<AppSettings> appSettings)
        {
            _appSettings = appSettings.Value;
        }

        private TyöajanseurantaContext context = new TyöajanseurantaContext();

        public User Authenticate(string KäyttäjäNimi, string Salasana)
        {

            var user = context.Users.SingleOrDefault(x => x.KäyttäjäNimi == KäyttäjäNimi && x.Salasana == Salasana);

            // Jos ei käyttäjää löydy palautetaan null
            if (user == null)
            {
                return null;
            }

            // Jos käyttäjä löytyy:
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_appSettings.Key);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new System.Security.Claims.ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.Name, user.UserId.ToString()),
                    new Claim(ClaimTypes.Role, "Admin"),
                    new Claim(ClaimTypes.Version, "V5.9")//ONKO TÄMÄ CORE VERSIO? VAI JOKU MUU NUGETTI?
                }),
                Expires = DateTime.UtcNow.AddDays(2), // Montako päivää token on voimassa

                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            user.Token = tokenHandler.WriteToken(token);

            user.Salasana = null; // poistetaan salasana ennenkuin palautetaan

            return user; // Palautetaan kutsuvalle controllerimetodille user ilman salasanaa
        }
    }
}
