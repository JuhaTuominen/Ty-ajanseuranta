﻿using TyöAjanSeuranta.Models;

namespace TyöAjanSeuranta.Services.Interfaces
{
    public interface IAuthenticateService
    {
        User Authenticate(string KäyttäjäNimi, string Salasana);
    }
}